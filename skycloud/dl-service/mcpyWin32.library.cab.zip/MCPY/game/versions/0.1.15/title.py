from tkinter import *

def single():
    import main
def multi():
    canvas.create_text(400, 575, text='Multiplayer support coming soon!', font=('Courier', 22))
def leave():
    quit()
def options():
    
    canvas.pack()
    options_background = PhotoImage(file='assets/textures/title/options_background.gif')
    canvas.create_image(0, 0, anchor=NW, image=options_background)
    
    
def credit():
    tk = Tk()
    canvas = Canvas(tk, width=800, height=750)
    canvas.pack()
    canvas.create_text(80, 10, text='==================', font=('Courier', 10))
    canvas.create_text(80, 25, text='Minecraft Credits', font=('Courier', 10))
    canvas.create_text(80, 40, text='==================', font=('Courier', 10))
    canvas.create_text(80, 55, text='', font=('Courier', 10))
    canvas.create_text(80, 70, text='Head of Minecraft', font=('Courier', 10))
    canvas.create_text(80, 85, text='    Andrew Oswald', font=('Courier', 10))
    canvas.create_text(80, 100, text='', font=('Courier', 10))
    canvas.create_text(80, 115, text='Game Developers', font=('Courier', 10))
    canvas.create_text(80, 130, text='    Andrew Oswald', font=('Courier', 10))
    canvas.create_text(80, 145, text='    Katie Oswald', font=('Courier', 10))
    canvas.create_text(80, 160, text='    John Kopechek', font=('Courier', 10))
    canvas.create_text(80, 175, text='', font=('Courier', 10))
    canvas.create_text(80, 190, text='                                                                                "Twenty years from now you will be more disappointed by the things that you didnt do than by the  ', font=('Courier', 10))
    canvas.create_text(80, 205, text='                                                              ones you did do. So throw off the bowlines. Sail away from the safe harbor.', font=('Courier', 10))
    canvas.create_text(80, 220, text='                                                       Catch the trade winds in your sails. Explore. Dream. Discover."', font=('Courier', 10))
    canvas.create_text(80, 235, text=' - Unknown', font=('Courier', 10))
    
tk=Tk()

canvas = Canvas(tk, width=800, height=750)
canvas.pack()
my_image = PhotoImage(file='assets/textures/title/title_background.gif')
canvas.create_image(0, 0, anchor=NW, image=my_image)
mc_image = PhotoImage(file='assets/textures/title/minecraft.gif')
edition_image = PhotoImage(file='assets/textures/title/edition.gif')
canvas.create_image(265, 185, anchor=NW, image=edition_image)
canvas.create_image(65, 75, anchor=NW, image=mc_image)
button_standard_image = PhotoImage(file='assets/textures/title/gui/button_bgtrue.gif')
button_standard_multi_image = PhotoImage(file='assets/textures/title/gui/button_bg1.gif')

button_click_image = PhotoImage(file='assets/textures/title/gui/button_bg_hover.gif')
Button(tk, text='Multiplayer', image=button_standard_multi_image, command=multi).place(x=200, y=360)
Button(tk, text='Singleplayer', image=button_standard_image, command=single).place(x=200, y=300)
button_options_image = PhotoImage(file='assets/textures/title/gui/button_options.gif')
button_quit_image = PhotoImage(file='assets/textures/title/gui/button_bg2.gif')
Button(tk, text='Singleplayer', image=button_quit_image, command=leave).place(x=200, y=480)
Button(tk, text='Singleplayer', image=button_options_image, command=options).place(x=200, y=420)
Button(tk, text='(C) Microsoftware', command=credit).place(x=610, y=715)
tk.title("Minecraft Python Edition")
tk.mainloop()
