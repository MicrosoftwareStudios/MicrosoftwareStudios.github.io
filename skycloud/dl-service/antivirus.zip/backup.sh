#! /bin/bash

sudo cp -r ~/Documents ~/Desktop/antivirus/backup
sudo cp -r ~/Videos ~/Desktop/antivirus/backup
sudo cp -r ~/Pictures ~/Desktop/antivirus/backup
sudo cp -r ~/Music ~/Desktop/antivirus/backup
