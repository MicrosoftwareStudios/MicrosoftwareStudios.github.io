#! /bin/bash
sudo cp -r ~/Desktop/antivirus/backup/Documents ~/Documents
sudo cp -r ~/Desktop/antivirus/backup/Pictures ~/Pictures
sudo cp -r ~/Desktop/antivirus/backup/Videos ~/Videos
sudo cp -r ~/Desktop/antivirus/backup/Music ~/Music
