#! /bin/bash
echo
echo 'INTERNAL ALPHA BUILD. NOT FOR DISTRIBUTION OR BETA TESTING!'
echo 'Welcome to the Minecraft Python Edition Launcher!'
echo
echo '[1] Launch current Game'
echo '[2] Edit Instances'
echo '[3] View changelog'
echo
read -p 'Choose an option : ' OPTION
if [ $OPTION == 1 ]; then
    lxterminal -t Output --command=~/Minecraft-Python-Edition/launcher/launcher-output.sh
    date '+%Y%-m%d-%H%M%S' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo ' ' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo '<Begin new instance>' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo 'Loading Tkinter...' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo 'Done.' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo 'Loading Resource Packs...' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo 'Done.' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo 'Loading Mods...' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo 'Done.' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo 'Loading assets...' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo 'Done.' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo 'Starting Minecraft...' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    
else
    if [ $OPTION == 2 ]; then
        clear
        echo What would you like to do?
        echo '[1] Create an instance'
        echo '[2] View available versions'
        echo '[3] View instances'
        echo
        read -p 'Choose an option : ' INSTANCEOPTION
        if [ $INSTANCEOPTION == 1 ]; then
            echo 'coming soon :)!'
            read -p 'Continue?'
        else
            if [ $INSTANCEOPTION == 2 ]; then
                echo v. 0.0.15 Alpha
                echo v. 0.0.1 Alpha
                read -p 'continue test?'
            else
                if [ $INSTANCEOPTION == 3 ]; then
                    echo Coming soon!
                fi
            fi
        fi
    else
        if [ $OPTION == 3 ]; then
            clear
            nano ~/Minecraft-Python-Edition/launcher/changelog.txt
        fi
    fi
fi
clear
echo
echo 'Welcome to the Minecraft Python Edition Launcher!'
echo
echo '[1] Launch current Game'
echo '[2] Edit Instances'
echo '[3] View changelog'
echo
read -p 'Choose an option : ' OPTION
if [ $OPTION == 1 ]; then
    lxterminal -t Output --command=~/Minecraft-Python-Edition/launcher/launcher-output.sh
    date '+%Y%-m%d-%H%M%S' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo ' ' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo '<Begin new instance>' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo 'Loading Tkinter...' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo 'Done.' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo 'Loading Resource Packs...' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo 'Done.' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo 'Loading Mods...' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo 'Done.' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo 'Loading assets...' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo 'Done.' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
    echo 'Starting Minecraft...' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
else
    if [ $OPTION == 2 ]; then
        exit
    else
        if [ $OPTION == 3 ]; then
            clear
            nano ~/Minecraft-Python-Edition/launcher/changelog.txt
        fi
    fi
fi
clear
echo
echo 'Welcome to the Minecraft Python Edition Launcher!'
echo
echo '[1] Launch current Game'
echo '[2] Edit instances'
echo '[3] View changelog'
echo
read -p 'Choose an option : ' OPTION
if [ $OPTION == 1 ]; then
    echo '[1] v0.1.15 Alpha'
    echo '[2] v0.1.1 Alpha'
    read -p 'Which version would you like to launch? : '  instancelaunch
    if [ $instancelaunch == 1 ]; then
        lxterminal --command=~/Minecraft-Python-Edition/launcher/launcher-output-1.15.sh
        date '+%Y%-m%d-%H%M%S' >> ~/Minecraft-Python-Edition/launcher/logs/log2.json
        echo ' ' >> ~/Minecraft-Python-Edition/launcher/logs/log2.json
        echo '<Begin new instance>' >> ~/Minecraft-Python-Edition/launcher/logs/log2.json
        echo 'Loading Tkinter...' ~/Minecraft-Python-Edition/launcher/logs/log2.json
        echo 'Done.' >> ~/Minecraft-Python-Edition/launcher/logs/log2.json
        echo 'Loading Resource Packs...' ~/Minecraft-Python-Edition/launcher/logs/log2.json
        echo 'Done.' >> ~/Minecraft-Python-Edition/launcher/logs/log2.json
        echo 'Loading Mods...' >> ~/Minecraft-Python-Edition/launcher/logs/log2.json
        echo 'Done.' >> ~/Minecraft-Python-Edition/launcher/logs/log2.json
        echo 'Loading assets...' >> ~/Minecraft-Python-Edition/launcher/logs/log2.json
        echo 'Done.' >> ~/Minecraft-Python-Edition/launcher/logs/log2.json
        echo 'Starting Minecraft...' >> ~/Minecraft-Python-Edition/launcher/logs/log2.json
    else
        if [ $instancelaunch == 2 ]; then
            lxterminal --command=~/Minecraft-Python-Edition/launcher/launcher-output.sh
            date '+%Y%-m%d-%H%M%S' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
            echo ' ' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
            echo '<Begin new instance>' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
            echo 'Loading Tkinter...' ~/Minecraft-Python-Edition/launcher/logs/log1.json
            echo 'Done.' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
            echo 'Loading Resource Packs...' ~/Minecraft-Python-Edition/launcher/logs/log1.json
            echo 'Done.' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
            echo 'Loading Mods...' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
            echo 'Done.' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
            echo 'Loading assets...' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
            echo 'Done.' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
            echo 'Starting Minecraft...' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
        fi
    fi
    
    
else
    if [ $OPTION == 2 ]; then
        exit
    else
        if [ $OPTION == 3 ]; then
            clear
            nano ~/Minecraft-Python-Edition/launcher/changelog.txt
        else
            if [ $OPTION == 5 ]; then
                echo "Hello, I'm an Easter Egg. You Found Me!"
                play /home/andrew/Minecraft-Python-Edition/game/versions/v0.1.15-Alpha_Prerelease/assets/soundfiles/music/game/calm1.ogg
            fi
                    
        fi
    fi
fi
