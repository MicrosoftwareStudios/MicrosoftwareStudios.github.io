#! /bin/bash

echo '###########################################'
echo '#                 Login                   #'
echo '#    Please login to your Microsoftware   #'
echo '#             Employee Account.           #'
echo '#  THIS IS AN INTERNAL ALPHA BUILD! NOT   #'
echo '#     FOR DISTRIBUTION OR BETA TESTING.   #'
echo '###########################################'
echo
read -p 'Name : ' USER
read -p 'Employee ID # : ' PASS
if [ $USER == Andrew ]; then
	if [ $PASS == 1234 ]; then
		echo Logging in...
		clear
		/home/andrew/Minecraft-Python-Edition/launcher/launcher.sh
		exit
	else
		echo Incorrect login credentials.
		read -p 'Exit?'
	fi
else
	if [ $USER == Katie ]; then
		if [ $PASS == 1563 ]; then
			echo Logging in...
			clear
			/home/andrew/Minecraft-Python-Edition/launcher/launcher.sh
			exit
		else
			echo Incorrect login credentials.
			read -p 'Exit?'
		fi
	fi
if [ $USER == DEBUG ]; then
		if [ $PASS == mswstudios ]; then
			echo Logging in...
			echo You have logged into the DEBUG account. This account is for testing features only. Leaking of the credentials is prohibited
			read -p 'Continue?'
			clear
			/home/andrew/Minecraft-Python-Edition/launcher/launcher.sh
			exit
		else			
			echo Incorrect login credentials.
			read -p 'Exit?'
		fi
	else
		echo Incorrect login credentials.
		read -p 'Exit?'
	fi
fi
if [ $USER == NEW ]; then
	read -p 'What would you like your username to be? : ' NEWNAME
	read -p 'What would you like your password to be? : ' NEWPASS
	read -p 'Please confirm your password : ' PASSCONFIRM
	if [ $NEWPASS == $PASSCONFIRM ]; then
		echo Password confirmed.
	else
		echo Passwords did not match.
		read -p 'Press ENTER to continue...'
		exit
	fi
fi

