#! /bin/bash
clear
echo 'Loading Tkinter...'
echo 'Done.'
echo 'Loading Resource Packs...'
echo 'Done.'
echo 'Loading Mods...'
echo 'Done.'
echo 'Loading assets...'
echo 'Done.'
echo 'Starting Minecraft...'
bash ~/Minecraft-Python-Edition/game/0.0.1a.mc
echo 'Game ended.'
echo 'Game ended.' >> ~/Minecraft-Python-Edition/launcher/logs/log1.json
read -p 'Press any key to continue...'

